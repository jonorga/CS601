function get3Segments(param: number[] | string) :boolean {
	if (param instanceof String) return false;
	else return true;
}