export function getToday() {
	return new Date();
}