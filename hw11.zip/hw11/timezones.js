import { locations } from './locs.js';
class currentDateTime {
}
currentDateTime.dt = "";
function removeTimezone(event) {
    event.stopPropagation();
    const target = event.currentTarget;
    target.parentElement.remove();
}
function clearOptionList() {
    const dd_div = document.getElementById("dropdown_div");
    if (dd_div == null || dd_div == undefined)
        return;
    const all_option_divs = dd_div.getElementsByTagName("div");
    Object.keys(all_option_divs).map(() => { all_option_divs[0].remove(); });
}
function editTime(event) {
    event.stopPropagation();
    const target = event.currentTarget;
    currentDateTime.dt = target.value;
    const content = target.parentElement.getAttribute("content").split(";");
    currentDateTime.offset = Number(content[2]) - 4;
}
function editTimezoneTime(event) {
    const target = event.currentTarget;
    if (target.getElementsByTagName("input").length == 1) {
        event.stopPropagation();
        return;
    }
    const display_div = document.getElementById("display");
    if (display_div == null)
        return;
    const all_display_divs = display_div.getElementsByTagName("div");
    Object.keys(all_display_divs).map((i) => {
        const zone = all_display_divs[Number(i)];
        const child = zone.getElementsByTagName("input");
        if (child.length == 1)
            child[0].remove();
    });
    const dt_select = document.createElement("input");
    dt_select.type = "datetime-local";
    dt_select.addEventListener("change", editTime);
    target.appendChild(dt_select);
}
function optionEvent(event) {
    const target = event.currentTarget;
    const content = target.getAttribute("content");
    if (content == null)
        return;
    const new_div = document.createElement("div");
    const para = document.createElement("p");
    const btn = document.createElement("button");
    para.innerHTML = "Loading...";
    btn.innerHTML = "Remove location";
    btn.addEventListener("click", removeTimezone);
    new_div.addEventListener("click", editTimezoneTime);
    new_div.appendChild(para);
    new_div.appendChild(btn);
    new_div.classList.add("display_item");
    new_div.setAttribute("content", content);
    clearOptionList();
    if (document.getElementById("display") != null && document.getElementById("display") != undefined)
        document.getElementById("display").appendChild(new_div);
}
function addListOption(cityproper, zipcode, zone) {
    const new_div = document.createElement("div");
    const para = document.createElement("p");
    para.innerHTML = cityproper + ", " + zipcode + " (UTC-" + zone + ")";
    new_div.appendChild(para);
    new_div.addEventListener("click", optionEvent);
    new_div.classList.add("dd_option");
    new_div.setAttribute("content", cityproper + ";" + zipcode + ";" + zone);
    if (document.getElementById("dropdown_div") != null && document.getElementById("dropdown_div") != undefined)
        document.getElementById("dropdown_div").appendChild(new_div);
}
function searchEvent() {
    clearOptionList();
    if (document.getElementById("search_input") == null || document.getElementById("search_input") == undefined)
        return;
    const input_element = document.getElementById("search_input");
    const input = input_element.value;
    if (input == null || input == "")
        return;
    let list_limit = 5;
    if (input.match(/[a-zA-Z]/)) {
        const lower_input = input.toLowerCase();
        const regex = new RegExp(lower_input);
        for (let key in locations.cities) {
            if (key.match(regex)) {
                addListOption(locations.cities[key].proper, locations.cities[key].zip, locations.cities[key].zone);
                list_limit--;
            }
            if (list_limit <= 0)
                break;
        }
    }
    else if (input.match(/\d+/)) {
        const regex = new RegExp(input);
        for (let key in locations.zipcodes) {
            if (key.match(regex)) {
                addListOption(locations.zipcodes[key].proper, key, locations.zipcodes[key].zone);
                list_limit--;
            }
            if (list_limit <= 0)
                break;
        }
    }
}
async function dynamicDisplay() {
    const display_div = document.getElementById("display");
    if (display_div == null || display_div == undefined)
        return;
    while (true) {
        const all_display_divs = display_div.getElementsByTagName("div");
        if (all_display_divs.length > 0) document.getElementById("display_hint").style.display = "block";
        else document.getElementById("display_hint").style.display = "none";
        Object.keys(all_display_divs).map((i) => {
            const content = all_display_divs[Number(i)].getAttribute("content");
            if (content != null && content != "") {
                const content_parsed = content.split(";");
                const para = all_display_divs[Number(i)].getElementsByTagName("p");
                let date = null;
                if (currentDateTime.dt == "") {
                    date = new Date();
                    date.setHours(date.getHours() - Number(content_parsed[2]));
                }
                else {
                    date = new Date(currentDateTime.dt);
                    date.setHours(date.getHours() - Number(content_parsed[2]) + currentDateTime.offset);
                }
                const date_format = date.toUTCString().split(",")[1].slice(0, -12);
                const time_temp = date.toUTCString().split(":");
                const min_sec = ":" + time_temp[1] + ":" + time_temp[2].slice(0, -4) + " ";
                const hour_format = date.getUTCHours() > 12 ? date.getUTCHours() % 12 + min_sec + "PM" : date.getUTCHours() == 12 ? date.getUTCHours() + min_sec + "PM" : date.getUTCHours() + min_sec + "AM";
                para[0].innerHTML = content_parsed[0] + " " + content_parsed[1] + " " + date_format
                    + " " + hour_format + " (UTC-" + content_parsed[2] + ")";
            }
        });
        await new Promise(r => setTimeout(r, 1000));
    }
}
export function pageFunction() {
    document.addEventListener("DOMContentLoaded", function () {
        const search_input = document.getElementById("search_input");
        if (search_input != null) {
            search_input.addEventListener("keyup", searchEvent);
        }
        dynamicDisplay();
    });
}
